let ClockSlogan = () => {
  return <p>This is the clock that shows the time in Bharat at all times.</p>;
};
export default ClockSlogan;
